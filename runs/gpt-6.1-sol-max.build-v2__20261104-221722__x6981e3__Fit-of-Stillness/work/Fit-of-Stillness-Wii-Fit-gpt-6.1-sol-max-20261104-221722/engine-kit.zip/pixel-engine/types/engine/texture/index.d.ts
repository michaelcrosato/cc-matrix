/**
 * Textures as data (docs/assets/textures.md): `TextureDef` layers baked headless to palette
 * texels, then a toon `textureMap`, a `spriteSheet` or `hudSprite` rows. `importSheet` slices a
 * pixel-art PNG sheet into defs (docs/assets/importing.md *Pixel-art sheets*).
 */
export type { Layer, OutlineLayer, PathLayer, PatternId, PatternLayer, PixelsLayer, TexSlot, TextureDef } from './types';
export { textureDef } from './helpers';
export { bakeTexture, meanColour, type BakedTexture, type BakeOptions } from './bake';
export { PATTERNS, type PatternSpec } from './patterns';
export { validateTexture, textureMetrics, MAX_ISOLATED, MAX_SEAM_EXCESS, type TextureCheck, type TextureMetrics } from './validate';
export { textureMap, spriteSheet, hudSprite, TextureError, type TextureOptions } from './convert';
export { TextureCatalog } from './catalog';
export { importPackSheet, importSheet, ALPHA_THRESHOLD, LEGEND_CHARS, SHEET_IMPORT_TOOL, type PackSheetOptions, type SheetCell, type SheetColour, type SheetImport, type SheetImportOptions, type SheetMerge } from './import';
export { TEXTURE_FAMILIES, TEXTURE_LIBRARY } from './library';
